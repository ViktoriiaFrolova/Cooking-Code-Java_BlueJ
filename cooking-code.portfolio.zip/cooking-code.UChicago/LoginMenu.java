import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

import java.util.Base64;// to encode the username and password

public class LoginMenu extends JFrame implements ActionListener, FocusListener 
{
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton;
    private Map<String, String> userCredentials;
    private JPanel contentPanel;

    public LoginMenu() 
    {
        setTitle("Login Menu");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        //panel for the background image
        contentPanel = new JPanel() 
        {
            @Override
            protected void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                ImageIcon backgroundImage = new ImageIcon(getClass().getResource("login window.png"));
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), null);
                }
            }
        };
        contentPanel.setLayout(new GridBagLayout());
        setContentPane(contentPanel);

        usernameField = new JTextField("Username");
        passwordField = new JPasswordField("Password");
        passwordField.setEchoChar((char) 0); // Show password text initially
        passwordField.addFocusListener(this); // Adding focus listener to handle password field visibility
        
        ImageIcon loginIcon = new ImageIcon(getClass().getResource("login.btn.png"));
        ImageIcon registerIcon = new ImageIcon(getClass().getResource("register.btn.png"));

        Image loginImage = loginIcon.getImage().getScaledInstance(130, 40, Image.SCALE_SMOOTH);
        Image registerImage = registerIcon.getImage().getScaledInstance(110, 33, Image.SCALE_SMOOTH);

        loginButton = new JButton(new ImageIcon(loginImage));
        registerButton = new JButton(new ImageIcon(registerImage));

        //background buttons are transparent
        loginButton.setOpaque(false);
        loginButton.setContentAreaFilled(false);
        loginButton.setBorderPainted(false);
        registerButton.setOpaque(false);
        registerButton.setContentAreaFilled(false);
        registerButton.setBorderPainted(false);

        loginButton.addActionListener(this);
        registerButton.addActionListener(this);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(-4, 10, 10, 10);
        c.gridx = 0;
        c.gridy = 2; 
        c.gridwidth = 2;
        c.fill = GridBagConstraints.HORIZONTAL;
        usernameField.setPreferredSize(new Dimension(240, 35));
        contentPanel.add(usernameField, c);

        c.gridy = 3; 
        passwordField.setPreferredSize(new Dimension(240, 35));
        c.insets = new Insets(2, 10, 10, 10);
        contentPanel.add(passwordField, c);

        c.gridx = 0;
        c.gridy = 4; 
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(0, 10, 10, 10);
        contentPanel.add(loginButton, c);

        c.gridy = 5; 
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(-15, 10, 10, 10);
        contentPanel.add(registerButton, c);

        userCredentials = loadCredentials();
        setVisible(true);
    }

public void actionPerformed(ActionEvent e)
{
    String username = usernameField.getText();
    String password = new String(passwordField.getPassword());

    if (e.getSource() == loginButton) 
    {
        // For debugging - print what we're looking for
        System.out.println("Attempting login with username: " + username);
        
        // Don't encode the input for comparison
        boolean found = false;
        for (Map.Entry<String, String> entry : userCredentials.entrySet()) 
        {
            // Decode the stored credentials for comparison
            String storedUsername = new String(Base64.getDecoder().decode(entry.getKey()));
            String storedPassword = new String(Base64.getDecoder().decode(entry.getValue()));
            
            // For debugging - print what we're comparing against
            System.out.println("Comparing against stored username: " + storedUsername);
            
            if (username.equals(storedUsername) && password.equals(storedPassword)) {
                found = true;
                break;
            }
        }
        
        if (found) {
            NewWindow newWindow = new NewWindow(getSize());
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } 
    else if (e.getSource() == registerButton)
    {
        // Keep the registration process encoding the credentials
        String encodedUsername = Base64.getEncoder().encodeToString(username.getBytes());
        String encodedPassword = Base64.getEncoder().encodeToString(password.getBytes());
        
        if (!userCredentials.containsKey(encodedUsername)) 
        {
            userCredentials.put(encodedUsername, encodedPassword);
            saveCredentials(userCredentials);
            JOptionPane.showMessageDialog(this, "Registration successful", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    @Override
    public void focusGained(FocusEvent e)
    {
        if (e.getSource() == passwordField) 
        {
            passwordField.setEchoChar('•'); //hide password
        }
    }

    
    @Override
    public void focusLost(FocusEvent e) 
    {
        if (e.getSource() == passwordField) 
        {
            passwordField.setEchoChar((char) 0); // Show password text when focus is lost
        }
    }

    private Map<String, String> loadCredentials() 
    {
        Map<String, String> credentials = new HashMap<>();
        try 
        {
            File file = new File("credentials.txt");
            if (file.exists()) 
            {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) 
                {
                   String[] parts = line.split(",");
                   if (parts.length == 2) 
                   {
                       String decodedUsername = new String(Base64.getDecoder().decode(parts[0]));
                       String decodedPassword = new String(Base64.getDecoder().decode(parts[1]));
                       credentials.put(decodedUsername, decodedPassword);
                   }
                }
                reader.close();
            }
        } 
        catch (IOException e) 
        {
        e.printStackTrace();
        }
        return credentials;
    }

    private void saveCredentials(Map<String, String> credentials) 
    {
        try 
        {
            File file = new File("credentials.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            for (Map.Entry<String, String> entry : credentials.entrySet()) 
            {
                String encodedUsername = Base64.getEncoder().encodeToString(entry.getKey().getBytes());
                String encodedPassword = Base64.getEncoder().encodeToString(entry.getValue().getBytes());
                writer.write(encodedUsername + "," + encodedPassword);
                writer.newLine();
            }
            writer.close();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) 
    {
        new LoginMenu();
    }
}
